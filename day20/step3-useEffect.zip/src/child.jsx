import { useEffect } from "react"

export let Child = (props) => { 
    // component mount
   /*  
   */
   useEffect(()=>{
        console.log("Child Component mounted")
    },[]);
    // component update
    useEffect(()=>{
        console.log("Child Component's power was updated")
    },[props.power])
    // component unmount
    useEffect(()=>{
        return () => {
            console.log("Child Component was unmounted")
        }
    },[]) 
   /*  
   useEffect(()=>{
        console.log("Child Component mounted")
        console.log("Child Component's power was updated")
        return () => {
            console.log("Child Component was unmounted")
        }
    },[props.power]) 
    */

    return <div>
               <h1>Child Component</h1>
               <h2>Power : {props.power}</h2>
               <h2>Version : {props.version}</h2>
           </div>
}
