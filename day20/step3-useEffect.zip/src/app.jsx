import { useState } from "react"
import { Child } from "./child"

export let App = () => { 
    let [show, setShow] = useState(true);
    let [power, setPower] = useState(1);
    let [version, setVersion] = useState(1);

    return <div>
               <h1>App Component</h1>
               <input value={"show / hide"} type="button" onClick={() => setShow(!show)} />
               <br />
               Power : <input value={power} type="range"  min={1} max={10} step={1} onChange={(evt) => setPower(Number(evt.target.value))} />
               Power : {power}
               <br />
               Version : <input value={version} type="range"  min={1} max={100} step={10} onChange={(evt) => setVersion(Number(evt.target.value))} />
               Version : {version}
               { show ? <Child version={version} power={power}/> : "child is hidden"}
           </div>
}


/* 
http://p.ip.fi/ZwzC
*/