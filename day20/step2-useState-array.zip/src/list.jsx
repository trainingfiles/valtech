const ListComp = (props) => {
    return <div>
               <h2>{ props.hero.title }</h2>
               <ol>
               { props.hero.list.map( (val, idx) => <li key={idx}>{ val }</li> ) }
               </ol>
            </div>
}

export default ListComp;