import { useState } from "react"
import ListComp from "./list";
import React from "react";

export let App = () => {
    let [herolist, setHeros ] = useState( { title : "Avengers", list : ["Ironman"] } );
    let ipref = React.createRef();
    let clickHandler = ()=>{
        if(ipref.current.value === "" ){
            alert("you must enter a hero's name")
        }else{
            setHeros( {...herolist, list : [...herolist.list, ipref.current.value] });
            ipref.current.value = "";
        }
    }
    return <div>
               <h1>App Component</h1>
               <label>Add New Avenger : </label>
               <input ref={ipref} type="text" defaultValue="" />
               <button onClick={ clickHandler }>Add Hero</button>
               <ListComp hero={herolist}/>
           </div>
}

/* 
http://p.ip.fi/s5BF
*/