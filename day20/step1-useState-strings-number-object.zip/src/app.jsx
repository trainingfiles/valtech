import { useState } from "react"
import ChildComp from "./child";

export let App = () => {
    /*     
    let [message, setMessage ] = useState("Welcome to your life");
    let [power, setPower ] = useState(0);
    let [version, setVersion ] = useState(0); 
    */
    let [state, setState ] = useState({ message : "", power : 0, version : 0});

    return <div>
                <h1>App Component</h1>
                <h2>Message : { state.message }</h2>
                <label htmlFor="msg">Change Message : </label>
                <input id="msg" type="text" onChange={ (evt)=> setState({...state, message : evt.target.value }) } />
                <br />
                <label htmlFor="pow">Change Power : </label>
                <input id="pow" type="range" onChange={ (evt)=> setState({...state, power : Number(evt.target.value)}) } />
                <br />
                <label htmlFor="ver">Change Version : </label>
                <input id="ver" type="range" onChange={ (evt)=> setState({...state, version : Number(evt.target.value) }) } />
                <ChildComp power={state.power} version={state.version} message={state.message}/>
           </div>
}