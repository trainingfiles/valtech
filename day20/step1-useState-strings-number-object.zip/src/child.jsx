const ChildComp = ({message, power, version}) => {
    return <div>
                <h2>Child Component</h2>
                <h3>Message From Parent : {message}</h3>
                <h3>Power From Parent : {power}</h3>
                <h3>version From Parent : {version}</h3>
            </div>
}

export default ChildComp;