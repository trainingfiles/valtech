import { useReducer, useRef, useState } from "react";

export let App = () => { 
   /*  
    let [movies, setMovies] = useState(0);
    let [power, setPower] = useState(1); 
    */
   
  //  let [vals, setVals] = useState({ power : 0, movies : 0 });

   // reducer 
   // pure function 
   let reducerFun = (state, action) => {
    switch(action.type){
        case "INCREASE_POWER" : return {...state, power : state.power + 1 }
        case "SET_POWER" : return {...state, power : action.payload }
        case "DECREASE_POWER" : return {...state, power : state.power - 1 }
        case "INCREASE_MOVIES" : return {...state, movies : state.movies + 1 }
        case "DECREASE_MOVIES" : return {...state, movies : state.movies - 1 }
        case "INCREASE_VERSION" : return {...state, version : state.version + 1 }
        default : return state;
    }
   };
   let ip = useRef()
   let [store, dispatch] = useReducer(reducerFun,{ power : 0, movies : 0, version : 1 })

    return <div>
               <h1>Use Reducer Hook</h1>
               <h3>Power : { store.power }</h3>
               <h3>Movies : { store.movies }</h3>
               <h3>Version : { store.version }</h3>
                <button onClick={()=> dispatch({ type : "INCREASE_POWER"})}>Increase Power</button>
                <button onClick={()=> dispatch({ type : "DECREASE_POWER"})}>Decrease Power</button>
                
                <input ref={ip} type="number" />
                <button onClick={()=> dispatch({ type : "SET_POWER", payload : Number(ip.current.value) })}>Set Power</button>

                <button onClick={()=> dispatch({ type : "INCREASE_MOVIES"})}>Increase Movies</button>
                <button onClick={()=> dispatch({ type : "DECREASE_MOVIES"})}>Decrease Movies</button>
                <button onClick={()=> dispatch({ type : "INCREASE_VERSION"})}>Increase Version</button>
               
           </div>
}

