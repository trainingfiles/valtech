import { useEffect, useState } from "react";
import axios from "axios";

export let Child = (props) => { 
    let [users, setUsers] = useState([]);
    // component mounted
    useEffect(()=>{
       axios.get("https://reqres.in/api/users?page=2")
       .then( res => {
        setUsers(res.data.data);
        // console.log(res.data.data)
        } )
       .catch()
       console.log("Child Component mounted")
    },[]);
    // component update
    useEffect(()=>{
        console.log("Child Component's power was updated")
    },[props.power])
    // component unmount
    useEffect(()=>{
        return () => {
            console.log("Child Component was unmounted")
        }
    },[]) 
   /*  
   useEffect(()=>{
        console.log("Child Component mounted")
        console.log("Child Component's power was updated")
        return () => {
            console.log("Child Component was unmounted")
        }
    },[props.power]) 
    */

    return <div>
               <h1>Child Component</h1>
               <h2>Power : {props.power}</h2>
               <h2>Version : {props.version}</h2>
               <hr />
               <ol>
                { users.map(({id,first_name,last_name,avatar}) => <li key={id}> <img src={avatar} alt={first_name} width={50} /> { first_name+" "+last_name }</li>)}
               </ol>
           </div>
}
