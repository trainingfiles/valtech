import DadajiComp from "./components/dadaji";

const { Component } = require("react")

class App extends Component{ 
    render(){
        return <div>
                    <h1>Use Context</h1>
                    <DadajiComp/>
               </div>
    }
}

export default App;