import React from "react";

let FamilyContext = React.createContext();
let Provider = FamilyContext.Provider;
let Consumer = FamilyContext.Consumer;

export { Provider, Consumer }
