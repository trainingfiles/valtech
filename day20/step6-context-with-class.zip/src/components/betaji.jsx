import { Component } from "react";
import { Consumer } from "../contexts/family.context";

class BetajiComp extends Component{
    render(){
        return <div style={ { border : "2px solid red", padding : "10px", margin : "10px" } }>
                    <h1>Child Component</h1>
                    <Consumer>{ (val) => <h3>{ val }</h3>  }</Consumer>
                </div>
    }
}

export default BetajiComp