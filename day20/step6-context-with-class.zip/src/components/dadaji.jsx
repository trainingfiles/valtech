import { Component } from "react";
import PapajiComp from "./papaji";
import { Provider } from "../contexts/family.context";
import Cousinji from "./cousinji";

class DadajiComp extends Component{
    state = {
        message : "default",
        ipval : ""
    }
    render(){
        return <div style={ { border : "2px solid red", padding : "10px", margin : "10px" } }>
                    <h1>Grand Parent Component</h1>
                    <input value={this.state.ipval} onChange={ (evt) => this.setState({ipval : evt.target.value })} type="text" />
                    <button onClick={() => this.setState({ message : this.state.ipval })}>Send Message</button>
                    <Provider value={this.state.message} >
                        <div>
                            <PapajiComp/>
                        </div>
                        <Cousinji/>
                    </Provider>
                </div>
    }
}

export default DadajiComp