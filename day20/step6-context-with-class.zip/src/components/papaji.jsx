import { Component } from "react";
import BetajiComp from "./betaji";

class PapajiComp extends Component{
    render(){
        return <div style={ { border : "2px solid red", padding : "10px", margin : "10px" } }>
                    <h1>Parent Component</h1>
                    <BetajiComp/>
                </div>
    }
}

export default PapajiComp