import React from "react";

let FamilyContext = React.createContext();

export { FamilyContext }
