import { BrowserRouter, Link, NavLink, Route, Routes } from "react-router-dom";
import "./style.css";
import AquamanComp from "./components/aquaman.component";
import BatmanComp from "./components/batman.component";
import HomeComp from "./components/home.component";
import NotFoundComp from "./components/notfound.component";
import SupermanComp from "./components/superman.component";
import WonderWomanComp from "./components/wonderwomen.component";
import { useState } from "react";

export function App(){
    /* let activeClass = (args) => {
        return args ? 'box' : null
    } */
    let [power, setPower] = useState(0);

    return <div className="container">
        <h1>Routing in React</h1>
        <h2>Power is { power }</h2>
        <input type="range" onInput={ (evt)=> setPower(Number(evt.target.value))} />
        <BrowserRouter>
       {/*  <ul>
            <li><Link className="box" to="/">Home</Link></li>
            <li><Link className="box" to="/batman">Batman</Link></li>
            <li><Link className="box" to="/superman">Superman</Link></li>
            <li><Link className="box" to="/aquaman">Aquaman</Link></li>
            <li><Link className="box" to="/wonderwomen">Wonder Women</Link></li>
            <li><Link className="box" to="/flash">Flash</Link></li>
            <li><Link className="box" to="/cybor">Cyborg</Link></li>
        </ul> */} 
        <ul>
            <li><NavLink className={({isActive})=> isActive ? 'box' : null} to="/">Home</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box' : null} to="/batman">Batman</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box' : null} to={'/superman/'+power}>Superman</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box' : null} to="/aquaman">Aquaman</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box' : null} to="/wonderwomen">Wonder Women</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box' : null} to="/flash">Flash</NavLink></li>
            <li><NavLink className={({isActive})=> isActive ? 'box' : null} to="/cybor">Cyborg</NavLink></li>
        </ul>
            <Routes>
                <Route path="/" element={<HomeComp/>} />
                <Route path="/batman" element={<BatmanComp/>} />
                <Route path="/superman/:args" element={<SupermanComp/>} />
                <Route path="/aquaman" element={<AquamanComp/>} />
                <Route path="/wonderwomen" element={<WonderWomanComp/>} />
                <Route path="/flash" element={<BatmanComp/>} />
                <Route path="*" element={<NotFoundComp/>} />
            </Routes>
        </BrowserRouter>
    </div>
}


/* 
http://p.ip.fi/zAan
*/