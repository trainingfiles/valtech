import { useParams } from "react-router-dom";

let SupermanComp = () => {
    let params = useParams();
    return <div className="card text-bg-info">
                <div className="card-header">
                    <h1>Superman Component</h1>
                    </div>
                <div className="card-body">
                    <h5 className="card-title">Justice League Heroe</h5>
                    <p className="card-text">
                        <b>Quantity : { params.args }</b>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos numquam deserunt impedit commodi quisquam nihil odio maiores optio porro. Nesciunt dicta nobis quo nulla atque odit dolorum nihil beatae dignissimos?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa nemo libero veniam, dolore tenetur veritatis doloremque nostrum quis hic temporibus corrupti nobis voluptatum reiciendis maxime sit dolorum repellat quam consectetur?
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati sint modi aliquid possimus culpa aperiam nisi nostrum quis mollitia eaque nihil, consequatur ad atque voluptates amet aut voluptatem, accusamus saepe?
                    </p>
                </div>
            </div>
  }
  export default SupermanComp;
  