let WonderWomanComp = () => {
    return <div className="card text-bg-danger">
                <div className="card-header">
                    <h1>Wonder Women Component</h1>
                </div>
                <div className="card-body">
                    <h5 className="card-title">Justice League Heroe</h5>
                    <p className="card-text">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos numquam deserunt impedit commodi quisquam nihil odio maiores optio porro. Nesciunt dicta nobis quo nulla atque odit dolorum nihil beatae dignissimos?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa nemo libero veniam, dolore tenetur veritatis doloremque nostrum quis hic temporibus corrupti nobis voluptatum reiciendis maxime sit dolorum repellat quam consectetur?
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati sint modi aliquid possimus culpa aperiam nisi nostrum quis mollitia eaque nihil, consequatur ad atque voluptates amet aut voluptatem, accusamus saepe?
                    </p>
                </div>
            </div>
  }
  export default WonderWomanComp;
  
  /* 
  http://p.ip.fi/8H46
  */