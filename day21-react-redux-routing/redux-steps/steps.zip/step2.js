const redux = require("redux");
const createStore = redux.legacy_createStore;

const ADD_HERO = "ADD_HERO";
const REMOVE_HERO = "REMOVE_HERO";
const SET_HERO = "SET_HERO";
//--------------------------
const ADD_MOVIE = "ADD_MOVIE";
const REMOVE_MOVIE = "REMOVE_MOVIE";
const SET_MOVIE = "SET_MOVIE";

let addHero = () => {
    return {
        type : ADD_HERO
    }
}
let removeHero = () => {
    return {
        type : REMOVE_HERO
    }
}
let setHero = (arg) => {
    return {
        type : SET_HERO,
        payload : arg
    }
}
let addMovie = () => {
    return {
        type : ADD_MOVIE
    }
}
let removeMovie = () => {
    return {
        type : REMOVE_MOVIE
    }
}
let setMovie = (arg) => {
    return {
        type : SET_MOVIE,
        payload : arg
    }
}

const initialState = {
    numberOfHeroes : 0,
    numberOfMovies : 0
}


const reducer = (state = initialState, action) => {
    switch(action.type){
        case ADD_HERO : return {
            ...state, 
            numberOfHeroes : state.numberOfHeroes + 1 
        }
        case SET_HERO : return {
            ...state, 
            numberOfHeroes : action.payload
        }
        case REMOVE_HERO : return {
            ...state, 
            numberOfHeroes : state.numberOfHeroes - 1 
        }
        case ADD_MOVIE : return {
            ...state, 
            numberOfMovies : state.numberOfMovies + 1 
        }
        case SET_MOVIE : return {
            ...state, 
            numberOfMovies : action.payload
        }
        case REMOVE_MOVIE : return {
            ...state, 
            numberOfMovies : state.numberOfMovies - 1 
        }
        default : return state
    }
} 

const store = createStore(reducer);

console.log("before subscription", store.getState());

let unsubscribe = store.subscribe(()=>{
    console.log("store was updated", store.getState());
});

// unsubscribe();

store.dispatch(addHero());
store.dispatch(addHero());
store.dispatch(removeHero());
store.dispatch(addHero());
store.dispatch(removeHero());
store.dispatch(addHero());
store.dispatch(removeHero());
store.dispatch(addHero());
store.dispatch(setHero(10));
store.dispatch(removeHero());
store.dispatch(addMovie());
store.dispatch(addMovie());
store.dispatch(removeMovie());
store.dispatch(addMovie());
store.dispatch(removeMovie());
store.dispatch(addMovie());
store.dispatch(removeMovie());
store.dispatch(addMovie());
store.dispatch(setMovie(10));
store.dispatch(removeMovie());
