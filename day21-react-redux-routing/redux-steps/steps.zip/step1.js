const redux = require("redux");
const createStore = redux.legacy_createStore;

const ADD_HERO = "ADD_HERO";
const REMOVE_HERO = "REMOVE_HERO";
const SET_HERO = "SET_HERO";

let addHero = () => {
    return {
        type : ADD_HERO
    }
}
let removeHero = () => {
    return {
        type : REMOVE_HERO
    }
}
let setHero = (arg) => {
    return {
        type : SET_HERO,
        payload : arg
    }
}

const initialState = {
    numberOfHeroes : 0
}

/* 
const reducer = (state = initialState, action) => {
    if(action.type === ADD_HERO){
        return {...state, numberOfHeroes : state.numberOfHeroes + 1}
    }else{
        return state
    }
} 
*/

const reducer = (state = initialState, action) => {
    switch(action.type){
        case ADD_HERO : return {
            ...state, 
            numberOfHeroes : state.numberOfHeroes + 1 
        }
        case SET_HERO : return {
            ...state, 
            numberOfHeroes : action.payload
        }
        case REMOVE_HERO : return {
            ...state, 
            numberOfHeroes : state.numberOfHeroes - 1 
        }
        default : return state
    }
} 

const store = createStore(reducer);

console.log("before subscription", store.getState());

let unsubscribe = store.subscribe(()=>{
    console.log("store was updated", store.getState());
});

// unsubscribe();

store.dispatch(addHero());
store.dispatch(addHero());
store.dispatch(removeHero());
store.dispatch(addHero());
store.dispatch(removeHero());
store.dispatch(addHero());
store.dispatch(removeHero());
store.dispatch(addHero());
store.dispatch(setHero(10));
store.dispatch(removeHero());
