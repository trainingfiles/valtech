const redux = require("redux");
const thunkMiddleWare = require("redux-thunk").default;
const axios = require("axios");


const createStore = redux.legacy_createStore;
const applyMiddleWare = redux.applyMiddleware;

const GET_USERS_REQUEST = "GET_USERS_REQUEST" ;
const GET_USERS_DATA = "GET_USERS_DATA" ;
const GET_USERS_ERROR = "GET_USERS_ERROR" ;

const getUsersRequest = () => {
    return {
        type : GET_USERS_REQUEST
    }
}
const getUsersData = (users) => {
    return {
        type : GET_USERS_DATA,
        payload : users
    }
}
const getUsersError = (error) => {
    return {
        type : GET_USERS_ERROR,
        payload : error
    }
}

const initialState = {
    loading : false,
    users : [],
    error : ""
}

const reducer = (state = initialState, action) => {
    switch(action.type){
        case GET_USERS_REQUEST : return {
            ...state, loading : true
        }
        case GET_USERS_DATA : return {
            ...state, loading : false, users : action.payload, error : ""
        }
        case GET_USERS_ERROR : return {
            ...state, loading : false, users : [], error : action.payload
        }
        default : return state
    }
};

const getUsers = () => {
    return function(dispatch){
        dispatch(getUsersRequest());
        axios.get("https://reqres.in/api/users?page=1")
        .then( res => dispatch(getUsersData(res.data.data)))
        .catch( error => dispatch(getUsersError(error)))
    }
}

const store = createStore(reducer,applyMiddleWare(thunkMiddleWare));

console.log(store.getState());

const unsubscribe = store.subscribe(() => {
    console.log(store.getState());
});


store.dispatch(getUsers());
