const { Component } = require("react");

class App extends Component{
    render(){
        return <h1>Welcome to your life</h1>
    }
}

export default App