import React, { Component } from "react";

class ChildComp extends Component{
    childRef1 = React.createRef();
    childRef2 = React.createRef();
    render(){
        return <div>
                    <h2>Child Component </h2>
                    {/* <h3>Message : { this.props.message }</h3> */}
                    <input ref={ this.childRef1 } type="text" />
                    <input ref={ this.childRef2 } type="text" />
                    <button onClick={ ()=> this.props.setChildMessage({val1 : this.childRef1.current.value, val2 : this.childRef2.current.value }) }>Send Message</button>
               </div>
    }
}

export default ChildComp




/* 

http://p.ip.fi/57vq

*/