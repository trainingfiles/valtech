import React, { Component } from "react";
import ChildComp from "./child";

class App extends Component{
    state = {
        message1 : "default",
        message2 : "default",
    }
    messageip = React.createRef()
    setMessage = () => {
        this.setState({ message1 : this.messageip.current.value })
    }
    setChildMessage = (nMessage) => {
        this.setState({ message1 : nMessage.val1, message2 : nMessage.val2 })
    }
    render(){
        return <div>
                    <h1>Component Communication</h1>
                    <h2>{ this.state.message1 }</h2>
                    <h2>{ this.state.message2 }</h2>
                    <input ref={ this.messageip } type="text" />
                    <button onClick={ this.setMessage }>Send Message</button>
                    <ChildComp setChildMessage={this.setChildMessage} />
               </div>
    }
}

export default App