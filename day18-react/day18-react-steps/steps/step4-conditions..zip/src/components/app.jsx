import { Component } from "react";

class App extends Component{
    state = {
        show : false
    }
    render(){
        return <div>
                    <h1>Conditions</h1>
                    <label htmlFor="">Show Terms and Conditions</label>
                    <input onChange={ ()=> this.setState({ show : !this.state.show })} type="checkbox" />
                    <hr />
                 { this.state.show && <p>
                <b>Terms and Conditions</b>
                <br />
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illum optio assumenda corporis dicta odit saepe nesciunt sequi molestias consequuntur et quo ad quae veritatis hic, iste recusandae! Minus, enim dolorem.
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsa tempore praesentium harum! Amet tenetur a ut ducimus laudantium quidem, rerum assumenda nostrum. Nostrum fugiat doloribus obcaecati eos architecto eligendi corrupti.
                Saepe velit, ut id necessitatibus voluptate officia. Cumque, nulla repellendus sed laudantium tempore neque id dolorum assumenda eius est molestias, vel, iusto quae animi quidem? Blanditiis hic voluptas quia id.
                Provident quasi inventore dolore? Itaque laudantium assumenda laborum nostrum labore, possimus odit deleniti iusto sint dolores at id, neque amet sapiente adipisci deserunt rem repudiandae. Temporibus praesentium quae fugiat laborum.
                Nam soluta eos ab quidem eum quis vero at dolorem modi delectus dolor totam quam, quisquam ex. In, esse facere earum enim, debitis dolorem eligendi explicabo nesciunt magni placeat tempore.
                Explicabo, laboriosam hic dignissimos ratione eius nemo provident nobis omnis ipsa magnam vero iure, nam rerum repellendus itaque animi vel. Laudantium quos provident aperiam tempora libero sint corporis deleniti minima.
                Reiciendis aut natus officiis cupiditate odio, veniam similique culpa optio non rem ex laudantium eius ea ipsam cumque sit ratione consequuntur molestiae eaque illo dicta excepturi enim perspiciatis. Autem, eveniet.
                Perferendis, beatae magnam. Eaque magnam quisquam fuga sunt soluta totam enim autem nesciunt nemo dolorum atque repudiandae dolorem velit aperiam quidem dolore nulla, quam vitae omnis doloribus reiciendis dignissimos dolor.
                Saepe tempore minus accusamus dignissimos cupiditate eos nisi vero error cum voluptatem consequatur delectus velit vitae, repellat laborum recusandae repellendus possimus fugit modi tenetur! Magni aut cumque veniam eos numquam.
                Non eos sunt culpa sit animi voluptatem. Quam sunt beatae harum rerum adipisci dolore modi, dicta in ipsa nostrum doloremque, optio animi dolorem eius. Esse quam dolore nisi molestiae consectetur.
                Quae numquam repellendus iure aspernatur suscipit? Natus aliquam, molestiae doloremque perferendis illum atque illo similique modi reiciendis suscipit hic doloribus delectus repellendus tempora tenetur, vitae soluta impedit sint. Officia, culpa?
            </p> }
            </div>
    }
}

export default App

/* 
http://p.ip.fi/tIlU
*/