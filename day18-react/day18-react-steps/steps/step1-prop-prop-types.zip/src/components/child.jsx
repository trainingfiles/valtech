import{ Component } from "react";
import PropTypes from "prop-types";

class ChildComp extends Component{
    /*  
    static defaultProps = {
        title : "Default Title",
        power : 0,
        message : "",
        list : []
    } 
    */
    /*    
    static propTypes = {
    message : PropTypes.string.isRequired,
    power : PropTypes.number
   } 
   */
   // temptotal = 2;
   state = {
    temptotal : 2
   }
    render(){
        let {message, power, agree, list, title} = this.props;
        return <div className="box">
                <h2>{ title }</h2>
                <ul>
                    <li>Message : { message } </li>
                    <li>Power : { power + this.state.temptotal } </li>
                    <li>Show : { agree ? "True" : "False" } </li>
                </ul>
                <p> This component is about { title } 
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora cum ab eos, reprehenderit soluta, expedita est delectus quaerat, maxime iure iusto? Reiciendis inventore odio nisi suscipit dicta corrupti omnis tenetur!
                </p>
                <button onClick={ ()=> {
                    // this.temptotal += 1;
                    // this.forceUpdate();
                    this.setState({ temptotal : this.state.temptotal+1 })
                    console.log(this.state.temptotal, power + this.state.temptotal);
                } }>Increase Power</button>
                <h3>Total Heroes : { list?.length }</h3>
                <p> This component is about { title } 
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempora cum ab eos, reprehenderit soluta, expedita est delectus quaerat, maxime iure iusto? Reiciendis inventore odio nisi suscipit dicta corrupti omnis tenetur!
                </p>
                <ol>{ list?.map( (val, idx) => <li key={idx}>{ val }</li>)}</ol>
            </div>
    }
}
/* 
ChildComp.defaultProps = {
    title : "Default Title",
    power : 0,
    list : []
} 
*/

export default ChildComp