import { Component } from "react";
import ChildComp from "./child";

class App extends Component{
    render(){
        return <div>
                    <h1>Props in React</h1>
                    <ChildComp title="Avengers" list={["Ironman", "Hulk", "Thor","Spiderman", "Black Widow"]} power={10} agree={true}  message="Child Component 1 Message"/>
                    <ChildComp title="Justice League" list={["Batman", "Superman", "Wonder Women"]} power={20} agree={false}  message="Child Component 2 Message"/>
                    <ChildComp list={["Harry potter", "Hermoini", "Ron"]}  />
                    <ChildComp title="Indic Heroes" list={["Shaktiman", "Krish", "Chota Bheem", "Minnal Murali"]} power={30} agree={true}  message="Child Component 3 Message"/>
                    <ChildComp />
                    <ChildComp title="Harry Potter" list={["Harry potter", "Hermoini", "Ron"]} power={40} agree={false}  message="Child Component 4 Message"/>
               </div>
    }
}

export default App