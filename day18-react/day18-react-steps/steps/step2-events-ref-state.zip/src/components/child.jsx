import { Component } from "react";

class ChildComp extends Component{
    render(){
        let {title, list} = this.props.vals;
        return <div>
                    <h2>{  title }</h2>
                   <ul>
                        { list.map( (val, idx) => <li key={idx}>{ val }</li>) }
                    </ul>
                </div>
    }
}

export default ChildComp