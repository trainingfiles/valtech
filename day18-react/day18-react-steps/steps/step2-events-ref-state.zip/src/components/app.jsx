import ChildComp from "./child";
import React, { Component } from "react";


class App extends Component{

   state = {
        first : {
            title : "Default",
            list : ["Ironman"],
            power : 5
        },
        second : {
            title : "Default",
            list : [ "Batman"],
            power : 8
        }
    } 

    ip = React.createRef()

   /*  constructor(){
        super();
        this.increaseAvengersPower = this.increaseAvengersPower.bind(this);
    } */
   /*  increaseAvengersPower = () => {
        this.setState({...this.state, first : {...this.state.first, power : this.state.first.power + 1} })
    } */
   /*  increaseAvengersPower(){
        this.setState({...this.state, first : {...this.state.first, power : this.state.first.power + 1} })
    } */
    increaseAvengersPowerBy1 = () => {
        this.setState({...this.state, first : {...this.state.first, power : this.state.first.power+1} })
    }
    increaseAvengersPowerByPrams(val){
        this.setState({...this.state, first : {...this.state.first, power : val} })
    }
    increaseAvengersPowerByInput = (evt) => {
        this.setState({...this.state, first : {...this.state.first, power : Number(evt.target.value) } })
    }
    increaseJusticeLeaguePower(){
        this.setState({...this.state, second : {...this.state.second, power : this.state.second.power + 1} })
    }
    increasePowerBy = () => {
        this.setState({...this.state, first : {...this.state.first, power : Number(this.ip.current.value) } })
    }
    render(){
        return <div>
                    <h1>State in React</h1>
                    <button onClick={ ()=> this.setState({...this.state, first : { ...this.state.first, title : "Avengers" } })}>change first title</button>
                    <button onClick={ ()=> this.setState({...this.state, second : { ...this.state.second, title : "Justice League"} })}>change second title</button>
                    <hr />
                   {/*  <button onClick={ this.increaseAvengersPower.bind(this) }>Increase Avenger's power</button> */}
                    <button onClick={ this.increaseAvengersPowerBy1 }>Increase Avenger's power</button>
                    <br />
                    <button onClick={ ()=> this.increaseAvengersPowerByPrams(10) }>Increase Avenger's power to 10</button>
                    <br />
                    <input value={this.state.first.power} type="range" onChange={ this.increaseAvengersPowerByInput } />
                    <br />
                    <input value={this.state.first.power} onChange={ this.increaseAvengersPowerByInput } ref={ this.ip } type="number" />
                    <button onClick={ this.increasePowerBy }>Increase Power By</button>
                    <hr />
                    <h2>Avenger's Power : { this.state.first.power }</h2>
                    <button onClick={ this.increaseJusticeLeaguePower.bind(this) }>Increase Justice Leagues's power</button>
                    <h2>Justice League's Power : { this.state.second.power }</h2>
                    <hr />
                    <ChildComp vals={ this.state.first } />
                    <ChildComp vals={ this.state.second } />
                </div>
    } 


   /* state = {
        firstname : "Tony",
        lastname : "Stark"
    }

    render(){
        return <div>
            <h1>State in React</h1>
            <input type="text" onChange={ (evt)=> this.setState({ firstname : evt.target.value }) } />
            <input type="text" onChange={ (evt)=> this.setState({ lastname : evt.target.value }) } />
            <br/>
            <button onClick={ () => this.setState( { firstname : "Iron" })}>Change First Name</button>
            <button onClick={ () => this.setState( { lastname : "Monger" })}>Change Last  Name</button>
            <ChildComp title={ this.state.firstname }/>
            <ChildComp title={ this.state.lastname }/>
        </div>
    }  */
}

export default App



/* 

http://p.ip.fi/RyVN

*/