import { Component } from "react";

class App extends Component{
    state = {
        power : 0
    }
    increasePower = () => {
        // console.log("BEFORE UPDATE")
        this.setState(
            function(existingState, existingProps){
                console.log(arguments[0], arguments[1])
             return { power : existingProps.boost }
            }, 
            function(){
            if(this.state.power === 10){
                alert("power is now 10")
            }
            // console.log("AFTER UPDATE")
            // console.log(this.state.power)// ???
        });
    }
    decreasePower = () => {
        this.setState({ power : this.state.power - 1 });
        console.log(this.state.power)// ???
    }
    setPower = () => {
        this.setState({ power : 10 });
        console.log(this.state.power)// ???
    }
    render(){
        return <div>
                    <h1>State of { this.props.title }</h1>
                    <h2>Power is : { this.state.power }</h2>
                    <button onClick={ this.increasePower }>Increase Power</button>
                    <button onClick={ this.decreasePower }>Decrease Power</button>
                    <button onClick={ this.setPower }>Set Power to 10</button>
               </div>
    }
}

export default App