import { Component } from "react";
class App extends Component{
    state = {
        user : {
            name : "vijay",
            email : "default",
            age : 0,
            phone : "default"
        }
    }
    /* 
    userNameHandler = (evt) => {
        this.setState({ user : { ...this.state.user, name : evt.target.value }}) ;
    }
    userAgeHandler = (evt) => {
        this.setState({ user : { ...this.state.user, age : evt.target.value }}) ;
    }
    usereMailHandler = (evt) => {
        this.setState({ user : { ...this.state.user, email : evt.target.value }}) ;
    }
    userPhoneHandler = (evt) => {
        this.setState({ user : { ...this.state.user, phone : evt.target.value }}) ;
    } 
    */
    userDetailsChangeHandler = (evt) => {
        this.setState({ user : { ...this.state.user, [evt.target.id] : evt.target.value }}) ;
    }
    render(){
       return <div className="container">
                   <h1>Forms in React</h1>
                   <div className="mb-3">
                    <label htmlFor="name" className="form-label">User Name</label>
                    <input onChange={ this.userDetailsChangeHandler } value={ this.state.user.name } className="form-control" id="name" placeholder="User Name"/>
                   </div>
                   <div className="mb-3">
                    <label htmlFor="email" className="form-label">User eMail</label>
                    <input onChange={ this.userDetailsChangeHandler } value={ this.state.user.email } type="email" className="form-control" id="email" placeholder="User eMail"/>
                   </div>
                   <div className="mb-3">
                    <label htmlFor="age" className="form-label">User Age</label>
                    <input onChange={this.userDetailsChangeHandler } value={ this.state.user.age } type="number" className="form-control" id="age" placeholder="User Age"/>
                   </div>
                   <div className="mb-3">
                    <label htmlFor="phone" className="form-label">User Phone</label>
                    <input onChange={this.userDetailsChangeHandler } value={ this.state.user.phone } className="form-control" id="phone" placeholder="Your Phone"/>
                   </div>
                   <div className="mb-3">
                   <button className="btn btn-primary">Register</button>
                   </div>
        <ul>
            <li>User Name : { this.state.user.name }</li>
            <li>User eMail : { this.state.user.email }</li>
            <li>User Age : { this.state.user.age }</li>
            <li>User Phone : { this.state.user.phone }</li>
        </ul>
              </div>
    }
}

export default App;

/* 
http://p.ip.fi/NGYI
*/