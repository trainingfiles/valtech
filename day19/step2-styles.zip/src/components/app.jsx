import { Component } from "react";
import myclass from  "../mystyle.css";
import client from "../client.module.css";

class App extends Component{
    render(){
        let styles = { backgroundColor : "papayawhip" , fontFamily : "Arial", padding : "10px", margin : "10px", textAlign : "justify" } ;
        return <div>
                   <h1>Styles</h1>
                   <article style={ styles }>
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Porro excepturi commodi, voluptatum maxime accusantium deleniti. Reprehenderit repudiandae unde tempora voluptate sit, voluptas aperiam. Veniam blanditiis asperiores dolorum amet, itaque officiis!
                    Quisquam laudantium laborum et possimus amet, unde iure quidem odit sit at placeat similique velit quas ipsam fuga quis perspiciatis beatae ipsum minima quasi blanditiis omnis? Culpa, sint non? Iste.
                    Facilis fuga impedit eos magni ducimus, dolorem libero eius doloribus quibusdam ipsum aliquam minus rem maiores reprehenderit velit possimus iste est quam. Atque velit fugiat fuga quidem id illo consequatur!
                    Dignissimos enim asperiores impedit harum voluptates veniam libero rerum officiis voluptatibus, saepe fugiat aut non iste est voluptatum? Cumque veniam harum aliquid culpa facere repellendus sequi! Excepturi eius delectus dolorem?
                   </article>
                   <hr />
                   <article  style={ {...styles, backgroundColor : "red"} }>
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Porro excepturi commodi, voluptatum maxime accusantium deleniti. Reprehenderit repudiandae unde tempora voluptate sit, voluptas aperiam. Veniam blanditiis asperiores dolorum amet, itaque officiis!
                    Quisquam laudantium laborum et possimus amet, unde iure quidem odit sit at placeat similique velit quas ipsam fuga quis perspiciatis beatae ipsum minima quasi blanditiis omnis? Culpa, sint non? Iste.
                    Accusantium magnam laboriosam illo laudantium impedit distinctio recusandae hic quod dicta, harum nulla deserunt explicabo quasi assumenda dignissimos nostrum, a odio vero rerum debitis suscipit rem. Reiciendis, et non. Quae?
                    Rem quidem nemo fuga harum exercitationem facere officiis reprehenderit error laboriosam! Delectus sapiente minima perferendis. Ex tempore nam praesentium a in asperiores assumenda quisquam accusantium! Quia corrupti nisi sequi dicta?
                    Dignissimos enim asperiores impedit harum voluptates veniam libero rerum officiis voluptatibus, saepe fugiat aut non iste est voluptatum? Cumque veniam harum aliquid culpa facere repellendus sequi! Excepturi eius delectus dolorem?
                   </article>
                   <hr />
                   <article style={ {...styles, border : "2px solid red"} }>
                    Accusantium magnam laboriosam illo laudantium impedit distinctio recusandae hic quod dicta, harum nulla deserunt explicabo quasi assumenda dignissimos nostrum, a odio vero rerum debitis suscipit rem. Reiciendis, et non. Quae?
                    Rem quidem nemo fuga harum exercitationem facere officiis reprehenderit error laboriosam! Delectus sapiente minima perferendis. Ex tempore nam praesentium a in asperiores assumenda quisquam accusantium! Quia corrupti nisi sequi dicta?
                    Dignissimos enim asperiores impedit harum voluptates veniam libero rerum officiis voluptatibus, saepe fugiat aut non iste est voluptatum? Cumque veniam harum aliquid culpa facere repellendus sequi! Excepturi eius delectus dolorem?
                   </article>
                   <hr />
                   <article style={ {...styles, boxShadow : "0px 0px 10px black"} }>
                    Dignissimos enim asperiores impedit harum voluptates veniam libero rerum officiis voluptatibus, saepe fugiat aut non iste est voluptatum? Cumque veniam harum aliquid culpa facere repellendus sequi! Excepturi eius delectus dolorem?
                   </article>
                   <hr />
                   <section className="box">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nostrum, repellat totam officia aliquam ipsam ducimus nisi hic illum at ipsa provident consequatur laudantium fugiat aperiam voluptas delectus quam qui fuga.
                    Inventore, iusto voluptatibus. Cumque beatae illum animi earum nobis impedit corrupti dicta nostrum culpa dolore deserunt consequuntur, suscipit nulla natus quaerat sint labore! At ea dicta incidunt magnam error explicabo?
                   </section>
                   <section className={client.box}>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nostrum, repellat totam officia aliquam ipsam ducimus nisi hic illum at ipsa provident consequatur laudantium fugiat aperiam voluptas delectus quam qui fuga.
                    Inventore, iusto voluptatibus. Cumque beatae illum animi earum nobis impedit corrupti dicta nostrum culpa dolore deserunt consequuntur, suscipit nulla natus quaerat sint labore! At ea dicta incidunt magnam error explicabo?
                   </section>
                   <section className={myclass.box}>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nostrum, repellat totam officia aliquam ipsam ducimus nisi hic illum at ipsa provident consequatur laudantium fugiat aperiam voluptas delectus quam qui fuga.
                    Inventore, iusto voluptatibus. Cumque beatae illum animi earum nobis impedit corrupti dicta nostrum culpa dolore deserunt consequuntur, suscipit nulla natus quaerat sint labore! At ea dicta incidunt magnam error explicabo?
                   </section>
               </div>
    }
}

export default App;
