import { Component } from "react";
import axios from "axios";

class App extends Component{
    state = {
        users : []
    }
    componentDidMount(){
        axios.get("https://reqres.in/api/users?page=2")
        .then( res => this.setState({ users : res.data.data }) )
        .catch( err => console.log("Error ", err) )
    }

    render(){
       return <div>
                   <h1>Ajax | API Call</h1>
                   <hr />
                   <ol>
                    { this.state.users.slice(4).map( val => <li key={ val.id }><img width="60" alt={ val.first_name+" "+val.last_name} src={val.avatar}/> { val.first_name+" "+val.last_name}</li> )}
                   </ol>
              </div>
    }
}

export default App;


/* 
http://p.ip.fi/Qk33
*/