import React from "react";

let FunMemoComp = (props) => {
        console.log("Function Memo Component was rendered", Math.random());
        return <div className="card" style={ {padding : '10px', margin : '10px'} }>
                    <div className="card-body">
                        <div className="card-title">
                        <h2>Function Memo Component</h2>
                        <div className="card-text">
                            <ul>
                                <li>Parent Power is { props.power }</li>
                                <li>Parent Version is { props.version }</li>
                                <li>Movie Details { JSON.stringify(props.movies) }</li>
                            </ul>
                        </div>
                        </div>
                    </div>
               </div>
}

export default React.memo(FunMemoComp) ;



