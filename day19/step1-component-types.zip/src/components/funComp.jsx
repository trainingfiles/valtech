import React from "react";

let FunComp = (props) => {
        console.log("Function Component was rendered", Math.random());
        return <div className="card" style={ {padding : '10px', margin : '10px'} }>
                    <div className="card-body">
                        <div className="card-title">
                        <h2>Function Component</h2>
                        <div className="card-text">
                            <ul>
                                <li>Parent Power is { props.power }</li>
                                <li>Parent Version is { props.version }</li>
                                <li>Movie Details { JSON.stringify(props.movies) }</li>
                            </ul>
                        </div>
                        </div>
                    </div>
               </div>
}

export default FunComp ;



