import { PureComponent } from "react";

class PureComp extends PureComponent{
    render(){
        console.log("PureComp was rendered", Math.random());
        return <div className="card" style={ {padding : '10px', margin : '10px'} }>
                    <div className="card-body">
                        <div className="card-title">
                        <h2>Pure Class Component</h2>
                        <div className="card-text">
                            <ul>
                                <li>Parent Power is { this.props.power }</li>
                                <li>Parent Version is { this.props.version }</li>
                                <li>Movie Details { JSON.stringify(this.props.movies) }</li>
                            </ul>
                        </div>
                        </div>
                    </div>
               </div>
    }
}

export default PureComp;



