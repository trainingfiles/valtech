import { Component } from "react";
import ClassComp from "./classComp";
import PureComp from "./pureComp";
import FunComp from "./funComp";
import FunMemoComp from "./memofunComp";

class App extends Component{
    state = {
        power : 0,
        version : 100,
        movies : [
            {
                "title" : "Ironman part 1",
                "likes" : 5
            },
            {   "title" : "Ironman part 2",
                "likes" : 5
            }
        ]
    }
    render(){
        return <div className="container">
                    <h1>Component Types</h1>
                    <h3>Power : { this.state.power }</h3>
                    <h3>Version : { this.state.version }</h3>
                    <h3>movies : { JSON.stringify(this.state.movies) }</h3>
                    <input type="range" value={ this.state.power } onChange={ (evt)=> this.setState({ power : Number(evt.target.value) }) } />
                    &nbsp;
                    &nbsp;
                    <button className="btn btn-primary" onClick={()=> this.setState({ version : Math.round(Math.random() * 100)})}>Change Version</button>
                    &nbsp;
                    &nbsp;
                    <button className="btn btn-primary" onClick={()=> this.setState({ power : 10 })}>Change Power to 10</button>
                    &nbsp;
                    &nbsp;
                    <button className="btn btn-primary" onClick={()=> this.setState({...this.state, movies :[{"title" : "Ironman part 1", "likes" : 5 }, {   "title" : "Ironman part 2", "likes" : this.state.movies[1].likes+1 } ]})}>Change 2nd movie likes</button>
                    {/* <ClassComp version={ this.state.version } power={this.state.power}/> */}
                    <ClassComp {...this.state}/>
                    <PureComp {...this.state}/>
                    <FunComp {...this.state}/>
                    <FunMemoComp {...this.state}/>
               </div>
    }
}

export default App;


/* 
http://p.ip.fi/9XKY
*/