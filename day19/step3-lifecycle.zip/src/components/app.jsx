import { Component } from "react";
import Child from "./child";

class App extends Component{
    state = {
        show : true,
        parentVersion : 1
    }
    constructor(){
        super();
        console.log("App Component's constructor was called")
    }
    componentDidMount(){
        console.log("App Component's componentDidMount was called")
    }
    render(){
        console.log("App Component's render was called")
       return <div>
                   <h1>Life Cycle</h1>
                   <label htmlFor="cb">Show / hide </label>
                   <input onChange={()=> this.setState({show : !this.state.show})} id="cb" type="checkbox" value={this.state.show} />
                   <input onChange={(evt)=> this.setState({parentVersion : Number(evt.target.value)})} type="range" value={this.state.parentVersion} />
                   Parent Version is : { this.state.parentVersion }
                   {this.state.show && <Child parent_version={ this.state.parentVersion } />}
               </div>
    }
}

export default App;


/* 
http://p.ip.fi/Qk33
*/